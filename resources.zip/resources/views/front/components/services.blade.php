<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title bg-white text-center text-primary px-3">Services</h6>
            <h1 class="mb-5">Our Services</h1>
        </div>
        <div class="row g-4">
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item rounded pt-3">
                    <div class="p-4">
                        <i class="fa fa-3x fa-globe text-primary mb-4"></i>
                        <h5>Safari Expeditions</h5>
                        <p>Immerse yourself in the magic of Kenya's wildlife and natural beauty with our carefully designed safari packages. Experience up-close encounters with iconic animals like lions, elephants, and giraffes in their natural habitats.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item rounded pt-3">
                    <div class="p-4">
                        <i class="fa fa-3x fa-hotel text-primary mb-4"></i>
                        <h5>Cultural Tours</h5>
                        <p>Delve into the vibrant culture and traditions of Kenya's diverse communities. Our cultural tours provide insights into local lifestyles, arts, crafts, and traditions, allowing you to connect with the heart of the country</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item rounded pt-3">
                    <div class="p-4">
                        <i class="fa fa-3x fa-user text-primary mb-4"></i>
                        <h5>Adventure Activities</h5>
                        <p>For the thrill-seekers, we offer adventure-packed activities such as trekking, mountain climbing, and hot air ballooning. Conquer the peaks of Mount Kenya or witness the stunning landscapes from above in a hot air balloon.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                <div class="service-item rounded pt-3">
                    <div class="p-4">
                        <i class="fa fa-3x fa-cog text-primary mb-4"></i>
                        <h5>Beach Getaways</h5>
                        <p>Relax and unwind on Kenya's pristine beaches along the Indian Ocean. Our beach holiday packages offer a perfect blend of relaxation and exploration, with options for water sports, marine life encounters, and serene coastal experiences.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item rounded pt-3">
                    <div class="p-4">
                        <i class="fa fa-3x fa-globe text-primary mb-4"></i>
                        <h5>Customized Tours</h5>
                        <p>Tailor your journey to your preferences with our personalized tour options. Whether you're a solo traveler, a couple, a family, or a group, we can create a unique itinerary that suits your interests and timeline.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item rounded pt-3">
                    <div class="p-4">
                        <i class="fa fa-3x fa-hotel text-primary mb-4"></i>
                        <h5>Transportation and Accommodation</h5>
                        <p>Enjoy comfortable transportation and accommodations throughout your trip. We ensure that you travel in style and stay in well-appointed lodges, hotels, or camps that align with your travel style.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item rounded pt-3">
                    <div class="p-4">
                        <i class="fa fa-3x fa-user text-primary mb-4"></i>
                        <h5>Guided Experiences</h5>
                        <p>Benefit from the expertise of our knowledgeable guides who provide insightful information about the destinations you visit. Their local expertise enhances your understanding and appreciation of Kenya's attractions.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                <div class="service-item rounded pt-3">
                    <div class="p-4">
                        <i class="fa fa-3x fa-cog text-primary mb-4"></i>
                        <h5>Conservation Initiatives</h5>
                        <p>Engage in responsible tourism and contribute to conservation efforts. We promote ethical wildlife encounters and support initiatives that protect Kenya's natural treasures for future generations.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>