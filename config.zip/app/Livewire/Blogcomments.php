<?php

namespace App\Livewire;

use Livewire\Component;

class Blogcomments extends Component
{
    public function render()
    {
        return view('admin.comments.index');
    }
}
