<?php

namespace App\Livewire;

use Livewire\Component;

class Rolepermissions extends Component
{
    public function render()
    {
        return view('livewire.rolepermissions')->layout('layouts.admin');
    }
}
