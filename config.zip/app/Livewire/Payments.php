<?php

namespace App\Livewire;

use Livewire\Component;

class Payments extends Component
{
    public function render()
    {
        return view('admin.payments.index');
    }
}
