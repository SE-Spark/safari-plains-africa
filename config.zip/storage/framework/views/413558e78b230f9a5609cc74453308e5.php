<div class="modal-content" style="width:70%;">
  <div class="modal-header">
        <h5 class="modal-title" id="confirmationModalLabel"><?php echo e($confirmationTitle); ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <!-- __BLOCK__ --><?php if($dishId): ?>
        DishId: <?php echo e($dishId); ?>

        <?php endif; ?> <!-- __ENDBLOCK__ -->
        <!-- __BLOCK__ --><?php if($dishIds): ?>
        DishIds: <?php echo json_encode($dishIds, 15, 512) ?>
        <?php endif; ?> <!-- __ENDBLOCK__ -->
        <p class="text-muted"><?php echo e($confirmationDescription); ?></p>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" wire:click="cancel">
            Cancel
        </button>
        <button type="button" class="btn btn-primary" wire:click="confirm">
            Confirm
        </button>
    </div>
</div><?php /**PATH C:\dev\tas\resources\views/livewire/delete-post.blade.php ENDPATH**/ ?>