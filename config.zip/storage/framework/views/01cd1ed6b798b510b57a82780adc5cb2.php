<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/quill/quill.snow.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/quill/quill.bubble.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/simple-datatables/style.css')); ?>" rel="stylesheet">  
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" data-navigate-track>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo $__env->yieldContent('styles'); ?>
    <style>
        table tr:first-child td input,
        table tr:first-child td select{
            font-size: 10px;
            min-width: 100px;
        }
        tr td{            
            font-size: 12px;
        }
        tr td:last-child {
            min-width: 150px;
        }
        tr td:last-child .flex div{
            width:60px;
            float:left;
        }
    </style>
</head>

<body>
    
    <?php echo $__env->make('layouts.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main id="main" class="main">
        <?php echo e($slot); ?>

    </main>
    <?php echo $__env->make('layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" data-navigate-once></script>                     
    <script src="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.min.js')); ?>" data-navigate-once></script>
    <script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>" data-navigate-once></script>
    <script src="<?php echo e(asset('assets/vendor/chart.js/chart.umd.js')); ?>" data-navigate-once></script>
    <script src="<?php echo e(asset('assets/vendor/echarts/echarts.min.js')); ?>" data-navigate-once></script>
    <script src="<?php echo e(asset('assets/vendor/quill/quill.min.js')); ?>" data-navigate-once></script>
    <script src="<?php echo e(asset('assets/vendor/simple-datatables/simple-datatables.js')); ?>" data-navigate-once></script>    
    <script src="<?php echo e(asset('assets/vendor/tinymce/tinymce.min.js')); ?>"data-navigate-track></script>
    <script src="<?php echo e(asset('assets/vendor/php-email-form/validate.js')); ?>" data-navigate-once></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>" ></script>
    <!-- <script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js" data-navigate-once></script> -->
    
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo $__env->yieldContent('scripts'); ?>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\dev\tas\resources\views/layouts/admin.blade.php ENDPATH**/ ?>