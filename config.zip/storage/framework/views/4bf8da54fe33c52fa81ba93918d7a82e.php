<form>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label><?php echo e(__(" Name")); ?></label>
                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="name" wire:change="validating">
                <!-- __BLOCK__ --><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label><?php echo e(__(" Description")); ?></label>
                <input type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="description" wire:change="validating">
                <!-- __BLOCK__ --><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="exampleInputEmail1"><?php echo e(__(" Status")); ?></label>
                <select class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="status" id="status" wire:model="status" wire:change="validating">
                    <option Selected>select status</option>
                    <option value="1">Active</option>
                    <option value="0">InActive</option>
                </select>
                <!-- __BLOCK__ --><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
            </div>
        </div>
    </div>
    <div class="card-footer ">
        <button type="button" wire:click="back" class="btn btn-secondary btn-round">Back</button>
        <!-- __BLOCK__ --><?php if($selected_id): ?>
        <button type="button" wire:click.prevent="update()" class="btn btn-primary btn-round float-right"><?php echo e(__('Save Changes')); ?></button>
        <?php else: ?>
        <button type="button" wire:click.prevent="savecreate()" class="btn btn-primary btn-round float-right"><?php echo e(__('Save & Create New')); ?></button>
        <button type="button" wire:click.prevent="save()" class="btn btn-primary btn-round float-right"><?php echo e(__('Save & Close')); ?></button>
        <?php endif; ?> <!-- __ENDBLOCK__ -->
    </div>
    <hr class="half-rule" />
</form><?php /**PATH C:\dev\tas\resources\views/admin/category/createUpdate.blade.php ENDPATH**/ ?>