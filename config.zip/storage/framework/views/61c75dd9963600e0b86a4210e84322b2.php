<div>
<div class="pagetitle">
        <h1>packages</h1>
    </div>
</div>
<?php /**PATH C:\dev\tas\resources\views/livewire/packages.blade.php ENDPATH**/ ?>