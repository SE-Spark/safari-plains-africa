<div class="container-fluid position-relative p-0">
    <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
        <a href="" class="navbar-brand p-0">
            <h1 class="text-primary m-0"><img src="<?php echo e(asset('logo.png')); ?>" alt="Logo"> Bonanza</h1>

        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-0">
                <a href="<?php echo e(route('home')); ?>" wire:navigate class="nav-item nav-link <?php if(request()->route()->getName() == 'home'): ?> active <?php endif; ?>">Home</a>
                <a href="<?php echo e(route('destination')); ?>" wire:navigate class="nav-item nav-link <?php if(request()->route()->getName() == 'destination'): ?> active <?php endif; ?>">Destination</a>
                <a href="<?php echo e(route('package')); ?>" wire:navigate class="nav-item nav-link <?php if(request()->route()->getName() == 'package'): ?> active <?php endif; ?>">Packages</a>

                
                <a href="<?php echo e(route('blog')); ?>" wire:navigate class="nav-item nav-link <?php if(request()->route()->getName() == 'blog'): ?> active <?php endif; ?>">Blog</a>
                <a href="<?php echo e(route('contact')); ?>" wire:navigate class="nav-item nav-link <?php if(request()->route()->getName() == 'contact'): ?> active <?php endif; ?>">Contact</a>
                <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('booking')); ?>" wire:navigate class="nav-item nav-link <?php if(request()->route()->getName() == 'booking'): ?> active <?php endif; ?>">Booking</a>
                <?php endif; ?>
            </div>
            <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('login',['account'=>'signin'])); ?>" class="btn btn-primary rounded-pill py-2 px-4" style="margin-right:20px !important;">Login</a>
            <a href="<?php echo e(route('login',['account'=>'signup'])); ?>" class="btn btn-primary rounded-pill py-2 px-4">Register</a>
            <?php else: ?>            
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary rounded-pill py-2 px-4">Dashboard</a>
            <?php endif; ?>
        </div>
    </nav>
    <div class="container-fluid bg-primary py-5 mb-5 hero-header">
        <div class="container py-5">
            <div class="row justify-content-center py-5">
                <div class="col-lg-10 pt-lg-5 mt-lg-5 text-center">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Enjoy Your Vacation With Us</h1>
                    <p class="fs-4 text-white mb-4 animated slideInDown">Bonanza Adventures Tours & Travel Ltd</p>
                    <div class="position-relative w-75 mx-auto animated slideInDown">
                        <input class="form-control border-0 rounded-pill w-100 py-3 ps-4 pe-5" type="text" placeholder="Eg: Diani">
                        <button type="button" class="btn btn-primary rounded-pill py-2 px-4 position-absolute top-0 end-0 me-2" style="margin-top: 7px;">Search</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\dev\tas\resources\views/front/layouts/navbar.blade.php ENDPATH**/ ?>