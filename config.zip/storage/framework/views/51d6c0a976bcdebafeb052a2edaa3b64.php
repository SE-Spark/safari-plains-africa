<div x-data="{ scrollToDestination: true }" x-init="scrollToDestination && $nextTick(() => delayScroll('#destinations',2000))">
    <div class="container-xxl py-5 destination" id="destinations">
        <!-- __BLOCK__ --><?php if(!$showMore): ?>
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Destination</h6>
                <h1 class="mb-5">Popular Destination</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <!-- __BLOCK__ --><?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="package-item">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="<?php echo e(\App\Helpers\HP::getImgUrl($v->image_url)); ?>" alt="">
                        </div>
                        <div class="d-flex border-bottom">
                            <small class="flex-fill text-center py-2"><i class="fa fa-map-marker-alt text-primary me-2"></i><?php echo e($v->name); ?></small>
                            <small class="flex-fill text-center py-2"><i class="fa fa-money-bill text-primary me-2"></i><?php echo e($v->packages->count()??0); ?> packages</small>
                        </div>
                        <div class="text-center p-4">
                            <p><?php echo e(implode(' ', array_slice(explode(' ', $v->description), 0, 30))); ?></p>
                            <div class="d-flex justify-content-center mb-2">
                                <a href="<?php echo e(route('destination',['id'=>$v->id])); ?>" class="btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 30px 30px 30px;">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
            </div>
        </div>
        <?php else: ?>
        
        <div class="container">
            <div class="row g-4 justify-content-center">
                <div class="col-lg-6 col-md-6 wow zoomIn" data-wow-delay="0.5s">
                    <a class="position-relative d-block overflow-hidden" href="">
                        <img class="img-fluid" src="<?php echo e(\App\Helpers\HP::getImgUrl($destination->image_url)); ?>" alt="">
                        <div class="bg-white text-danger fw-bold position-absolute top-0 start-0 m-3 py-1 px-2"><?php echo e($destination->packages->count()??0); ?> packages</div>
                        <div class="bg-white text-primary fw-bold position-absolute bottom-0 end-0 m-3 py-1 px-2"><?php echo e($destination->name); ?></div>
                    </a>
                </div>
                <div class="col-lg-6 col-md-6 wow fadeInUp m-auto" data-wow-delay="0.1s">
                    <div class="package-item">
                        <div class="d-flex border-bottom">
                            <small class="flex-fill text-center py-2"><i class="fa fa-map-marker-alt text-primary me-2"></i><?php echo e($destination->name); ?></small>
                            <small class="flex-fill text-center py-2"><i class="fa fa-money-bill text-primary me-2"></i><?php echo e($destination->packages->count()??0); ?> packages</small>
                        </div>
                        <div class="text-start p-4">
                            <h6 class="text-primary">Description</h6>
                            <p><?php echo e($destination->description); ?></p>
                        </div>
                    </div>
                </div>
                <h6 class="text-center text-primary">Available Packages</h6>
                <div class="col-12">
                    <div class="row g-4 justify-content-center">
                        <!-- __BLOCK__ --><?php $__currentLoopData = $destination->packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $dest = $package->destinations[0];
                        if($dest->status===0){
                        continue;
                        }
                        $img_url = $dest->image_url;
                        ?>
                        <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                            <div class="package-item">
                                <div class="overflow-hidden">
                                    <img class="img-fluid" src="<?php echo e(\App\Helpers\HP::getImgUrl($package->destinations[0]->image_url)); ?>" alt="">
                                </div>
                                <div class="d-flex border-bottom">
                                    <small class="flex-fill text-center border-end py-2"><i class="fa fa-map-marker-alt text-primary me-2"></i><?php echo e($package->name); ?></small>
                                    <small class="flex-fill text-center border-end py-2"><i class="fa fa-calendar-alt text-primary me-2"></i><?php echo e($package->number_of_days); ?> Days</small>
                                    <small class="flex-fill text-center py-2"><i class="fa fa-user text-primary me-2"></i><?php echo e($package->number_of_people); ?> Person</small>
                                </div>
                                <div class="text-center p-4">
                                    <h3 class="mb-0"><?php echo e(number_format($package->price).' KES'); ?></h3>
                                    <div class="mb-3">
                                        <small class="fa fa-star text-primary"></small>
                                        <small class="fa fa-star text-primary"></small>
                                        <small class="fa fa-star text-primary"></small>
                                        <small class="fa fa-star text-primary"></small>
                                        <small class="fa fa-star text-primary"></small>
                                    </div>
                                    <p><?php echo e($package->description); ?></p>
                                    <div class="d-flex justify-content-center mb-2">
                                        <a href="#" class="btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0 0 30px;">Read More</a>
                                        <a href="#" class="btn btn-sm btn-primary px-3" style="border-radius: 0 30px 30px 0;">Book Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?> <!-- __ENDBLOCK__ -->
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
     function delayScroll(elementId, delay) {
        setTimeout(() => {
            scrollTo(elementId);
        }, delay);
    }
    function scrollTo(elementId) {
        const element = document.querySelector(elementId);

        if (element) {
            element.scrollIntoView({
                behavior: 'smooth',
                block: 'start',
                inline: 'nearest'
            });
        }
    }
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\dev\tas\resources\views/front/destination.blade.php ENDPATH**/ ?>