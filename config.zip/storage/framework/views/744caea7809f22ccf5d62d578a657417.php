<!-- __BLOCK__ --><?php if(data_get($setUp, 'header.showMessageSoftDeletes') &&
        ($softDeletes === 'withTrashed' || $softDeletes === 'onlyTrashed')): ?>
    <div
        class="alert alert-warning my-1"
        role="alert"
    >
        <!-- __BLOCK__ --><?php if($softDeletes === 'withTrashed'): ?>
            <?php echo app('translator')->get('livewire-powergrid::datatable.soft_deletes.message_with_trashed'); ?>
        <?php else: ?>
            <?php echo app('translator')->get('livewire-powergrid::datatable.soft_deletes.message_only_trashed'); ?>
        <?php endif; ?> <!-- __ENDBLOCK__ -->
    </div>
<?php endif; ?> <!-- __ENDBLOCK__ -->
<?php /**PATH C:\dev\tas\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/frameworks/bootstrap5/header/message-soft-deletes.blade.php ENDPATH**/ ?>