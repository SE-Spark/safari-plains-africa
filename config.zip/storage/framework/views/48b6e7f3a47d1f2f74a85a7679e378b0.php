<div>
<div class="pagetitle">
        <h1>hotels</h1>
    </div>
</div>
<?php /**PATH C:\dev\tas\resources\views/livewire/hotels.blade.php ENDPATH**/ ?>