<div>
<div class="pagetitle">
        <h1>reviews</h1>
    </div>
</div>
<?php /**PATH C:\dev\tas\resources\views/livewire/reviews.blade.php ENDPATH**/ ?>