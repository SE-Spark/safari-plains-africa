<?php
    $inputAttributes = new \Illuminate\View\ComponentAttributeBag([
        'class' => $theme->checkbox->inputClass,
    ]);
    
    if (isset($ruleSetAttribute['attribute'])) {
        $inputAttributes = $inputAttributes->merge([
            $ruleSetAttribute['attribute'] => $ruleSetAttribute['value'],
        ]);
    }
?>
<!-- __BLOCK__ --><?php if($checkbox): ?>
    <!-- __BLOCK__ --><?php if($ruleHide): ?>
        <td
            class="<?php echo e($theme->checkbox->thClass); ?>"
            style="<?php echo e($theme->checkbox->thStyle); ?>"
        >
        </td>
    <?php elseif($ruleDisable): ?>
        <td
            class="<?php echo e($theme->checkbox->thClass); ?>"
            style="<?php echo e($theme->checkbox->thStyle); ?>"
        >
            <div class="<?php echo e($theme->checkbox->divClass); ?>">
                <label class="<?php echo e($theme->checkbox->labelClass); ?>">
                    <input
                        <?php echo e($inputAttributes); ?>

                        disabled
                        type="checkbox"
                    >
                </label>
            </div>
        </td>
    <?php else: ?>
        <td
            class="<?php echo e($theme->checkbox->thClass); ?>"
            style="<?php echo e($theme->checkbox->thStyle); ?>"
        >
            <div class="<?php echo e($theme->checkbox->divClass); ?>">
                <label class="<?php echo e($theme->checkbox->labelClass); ?>">
                    <input
                        x-data="{}"
                        type="checkbox"
                        <?php echo e($inputAttributes); ?>

                        x-on:click="window.Alpine.store('pgBulkActions').add($event.target.value, '<?php echo e($tableName); ?>')"
                        wire:model="checkboxValues"
                        value="<?php echo e($attribute); ?>"
                    >
                </label>
            </div>
        </td>
    <?php endif; ?> <!-- __ENDBLOCK__ -->
<?php endif; ?> <!-- __ENDBLOCK__ -->
<?php /**PATH C:\dev\tas\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/checkbox-row.blade.php ENDPATH**/ ?>