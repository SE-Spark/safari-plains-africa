    <svg class="" width="16" height="16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8 12.912l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L8 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                    </svg><svg class="" width="16" height="16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8 12.912l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L8 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                    </svg><svg class="" width="16" height="16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8 12.912l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L8 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                    </svg><svg class="" width="16" height="16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8 12.912l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L8 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                    </svg> 