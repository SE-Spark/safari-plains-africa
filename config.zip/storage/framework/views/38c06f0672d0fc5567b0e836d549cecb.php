<div class="container">
    <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
            <?php echo $__env->make('partials.sectionSuccessError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row justify-content-center">
                <div class="<?php if($loginMode): ?> col-md-4 <?php else: ?> col-md-6 <?php endif; ?> d-flex flex-column align-items-center justify-content-center">

                    <div class="d-flex justify-content-center py-4">
                        <a href="/" class="logo d-flex align-items-center w-auto">
                            <img src="<?php echo e(asset('logo.png')); ?>" alt="">
                            <span class="d-none d-lg-block">Bonanza</span>
                        </a>
                    </div>

                    <div class="card mb-3">

                        <div class="card-body">

                            <div class="pt-4 pb-2">
                                <h5 class="card-title text-center pb-0 fs-4">
                                    <!-- __BLOCK__ --><?php if($loginMode): ?>
                                    Login to Your Account
                                    <?php else: ?>
                                    Create an Account
                                    <?php endif; ?> <!-- __ENDBLOCK__ -->
                                </h5>
                                <p class="text-center small">
                                    <!-- __BLOCK__ --><?php if($loginMode): ?>
                                    Enter your email & password to login
                                    <?php else: ?>
                                    Enter your personal details to create account
                                    <?php endif; ?> <!-- __ENDBLOCK__ -->
                                </p>
                            </div>

                            <form class="row g-3 needs-validation" novalidate>
                                <!-- __BLOCK__ --><?php if(!$loginMode): ?>
                                <div class="col-6">
                                    <label for="firstName" class="form-label">First Name</label>
                                    <input wire:model='first_name' type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="firstName">
                                    <!-- __BLOCK__ --><?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                                </div>
                                <div class="col-6">
                                    <label for="lastName" class="form-label">Last Name</label>
                                    <input wire:model='last_name' type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lastName">
                                    <!-- __BLOCK__ --><?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                                </div>
                                <div class="col-6">
                                    <label for="phone" class="form-label">Phone</label>
                                    <input wire:model='phone' type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone">
                                    <!-- __BLOCK__ --><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                                </div>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                                <div class="<?php if(!$loginMode): ?> col-6 <?php else: ?> col-12 <?php endif; ?>">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="text" wire:model='email' class="form-control" id="email" required>
                                    <!-- __BLOCK__ --><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                                </div>
                                <div class="col-12">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" wire:model='password' class="form-control" id="password" required>
                                    <!-- __BLOCK__ --><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                                </div>
                                <!-- __BLOCK__ --><?php if(!$loginMode): ?>
                                <div class="col-12">
                                    <label for="renewPassword">Re-enter New Password</label>
                                    <input wire:model="password_confirmation" type="password" class="form-control  <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="renewPassword">
                                    <!-- __BLOCK__ --><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                                </div>
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                                <div class="col-5 mr-1" x-data="{ goBack: function() { window.history.back(); } }">
                                    <button type ="button"class="btn btn-secondary w-100" x-on:click="goBack">Back</button>
                                </div>

                                <div class="col-6">
                                    <!-- __BLOCK__ --><?php if($loginMode): ?>
                                    <button class="btn btn-primary w-100" wire:click.prevent='login'>Login</button>
                                    <?php else: ?>
                                    <button class="btn btn-primary w-100" wire:click.prevent='register'>Register</button>
                                    <?php endif; ?> <!-- __ENDBLOCK__ -->
                                </div>
                                <div class="col-12">
                                    <!-- __BLOCK__ --><?php if($loginMode): ?>
                                    <p class="small mb-0">Don't have account? <a href="javascript:;" wire:click.prevent='toggleMode'>Create an account</a></p>
                                    <?php else: ?>
                                    <p class="small mb-0">Already have an account? <a href="javascript:;" wire:click.prevent='toggleMode'>Log in</a></p>
                                    <?php endif; ?> <!-- __ENDBLOCK__ -->
                                </div>
                            </form>

                        </div>
                    </div>

                </div>
            </div>
        </div>

    </section>

</div>
<?php $__env->startPush('scripts'); ?>
<script>
    Livewire.on('updateUrl', params => {
        const account = params[0].account;
        history.replaceState({}, '', `<?php echo e(route('login')); ?>/${account}`);
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\dev\tas\resources\views/livewire/home-controller.blade.php ENDPATH**/ ?>