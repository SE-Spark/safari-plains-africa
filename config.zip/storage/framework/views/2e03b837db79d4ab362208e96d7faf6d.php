<div>
<div class="pagetitle">
    <h1>Destinations</h1>
</div>
<section class="section dashboard">
    <div class="row">
        <form wire:submit.prevent="create">
            <div>
                <label for="newDestinationName">Name:</label>
                <input wire:model="newDestination.name" type="text" id="newDestinationName">
                <!-- __BLOCK__ --><?php $__errorArgs = ['newDestination.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
            </div>
            <div>
                <label for="newDestinationDescription">Description:</label>
                <textarea wire:model="newDestination.description" id="newDestinationDescription"></textarea>
                <!-- __BLOCK__ --><?php $__errorArgs = ['newDestination.description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
            </div>
            <button type="submit">Create Destination</button>
        </form>
    </div>
    <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">
              Destinations
                <span class="text-end"></span>
              </h5>
              <div class="row d-flex justify-content-end">
                <div class="col-md-2 col-6">
                <a href="javascript:;" class="btn btn-success w-75 mr-4">Add New</a>
                </div>
              </div>
              <table class="table datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Description</th>
                    <th scope="col">Image</th>
                    <th scope="col">Status</th>
                  </tr>
                </thead>
                <tbody>
                  <!-- __BLOCK__ --><?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($destination->id); ?></th>
                    <td><?php echo e($destination->name); ?></td>
                    <td><?php echo e($destination->description); ?></td>
                    <td><?php echo e($destination->image_url); ?></td>
                    <td><?php echo e($destination->status); ?></td>
                    <td>
                        <button wire:click="edit(<?php echo e($destination->id); ?>)">Edit</button>
                        <button wire:click="delete(<?php echo e($destination->id); ?>)">Delete</button>
                    </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->

                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
</section>
</div><?php /**PATH C:\dev\tas\resources\views/livewire/destinations-component.blade.php ENDPATH**/ ?>