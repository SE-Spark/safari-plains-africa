<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('star-rating', ['rating' => 0]);

$__html = app('livewire')->mount($__name, $__params, 'Lx1f9tu', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH C:\dev\tas\storage\framework\views/25bca7fdd63378ee6b1fcbcb374e2958.blade.php ENDPATH**/ ?>