<div>
<div class="pagetitle">
        <h1>Booking item type</h1>
    </div>
</div>
<?php /**PATH C:\dev\tas\resources\views/admin/booking-items-type.blade.php ENDPATH**/ ?>